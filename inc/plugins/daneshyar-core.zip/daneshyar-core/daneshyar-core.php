<?php
/**
 * Plugin Name: Daneshyar Core
 * Description: This plugin related to Daneshyar Theme.
 * Version:     1.0.0
 * Author:      Isaac Shafaei
 * Author URI:  https://kitwp.com/
 */
function add_daneshyar_widget_categories( $elements_manager ) {
	$elements_manager->add_category(
		'daneshyar-category',
		[
			'title' => esc_html__( 'المان های دانشیار', 'daneshyar-core' ),
			'icon' => 'fa fa-plug',
		]
	);

}
add_action( 'elementor/elements/categories_registered', 'add_daneshyar_widget_categories' );

function register_daneshyar_widget( $widgets_manager ) {

	require_once( __DIR__ . '/widgets/lessons.php' );
	require_once( __DIR__ . '/widgets/ajax-search.php' );
	require_once( __DIR__ . '/widgets/course-carousel.php' );
	require_once( __DIR__ . '/widgets/blog.php' );
	require_once( __DIR__ . '/widgets/video-player.php' );

	$widgets_manager->register( new \Elementor_Daneshyar_Lessons_Widget() );
	$widgets_manager->register( new \Elementor_Daneshyar_Search_Widget() );
	$widgets_manager->register( new \Elementor_Daneshyar_Course_Carousel_Widget() );
	$widgets_manager->register( new \Elementor_Daneshyar_Blog_Widget() );
	$widgets_manager->register( new \Elementor_Daneshyar_Video_Player_Widget() );

}
add_action( 'elementor/widgets/register', 'register_daneshyar_widget' );

include_once(dirname(__FILE__).'/inc/function.php');