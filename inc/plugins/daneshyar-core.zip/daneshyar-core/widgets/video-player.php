<?php
class Elementor_Daneshyar_Video_Player_Widget extends \Elementor\Widget_Base {

	public function get_name() {
		return 'Video_Player';
	}

	public function get_title() {
		return esc_html__( 'ویدیو پلیر', 'daneshyar-core' );
	}

	public function get_icon() {
		return 'eicon-video-playlist';
	}

	public function get_categories() {
		return [ 'daneshyar-category' ];
	}

	public function get_keywords() {
		return [ 'daneshyar', 'دانشیار' ];
	}

	protected function _register_controls() {

        $this->start_controls_section(
            'blog_section',
            [
               'label' => esc_html__( 'Blog', 'daneshyar-core' ),
               'type' => \Elementor\Controls_Manager::SECTION,
            ]
         );
   
         $this->add_control(
            'number_of_item',
            [
               'label' => __( 'Number of Items', 'daneshyar-core' ),
               'type' => \Elementor\Controls_Manager::SLIDER,
               'range' => [
                  'no' => [
                     'min' => 1,
                     'max' => 100,
                     'step' => 1,
                  ],
               ],
               'default' => [
                  'size' => 6,
               ]
            ]
         );
   
   
   
         $this->add_control(
            'category',
            [
               'label' => esc_html__( 'Category', 'daneshyar-core' ),
               'type' =>\Elementor\Controls_Manager::SELECT2,
               'title' => esc_html__( 'Select a category', 'daneshyar-core' ),
               'multiple' => true,
               'options' => get_the_post_category(),
            ]
         );
   
         $this->add_control(
            'order',
            [
               'label' => __( 'Order', 'daneshyar-core' ),
               'type' => \Elementor\Controls_Manager::SELECT,
               'default' => 'DESC',
               'options' => [
                  'ASC'  => __( 'Ascending', 'daneshyar-core' ),
                  'DESC' => __( 'Descending', 'daneshyar-core' )
               ],
            ]
         );
   
         $this->end_controls_section();
   
   	  }
   
	protected function render(){ 

    $settings = $this->get_settings_for_display(); 

    $args = array(
        'post_type' => 'post',
        'posts_per_page' => $settings['number_of_item']['size'],
        'order' => $settings['order'],
        'tax_query' => array(
            'relation' => 'AND',
            array(
              'taxonomy' => 'post_format',
              'field' => 'slug',
              'terms' => 'post-format-video'
            )

        ),
    );

    if(!empty($settings['category'])){
        $args = array(
            'post_type' => 'post',
            'posts_per_page' => $settings['number_of_item']['size'],
            'order' => $settings['order'],
            'tax_query' => array(
                'relation' => 'AND',
                array(
                  'taxonomy' => 'category',
                  'terms' => $settings['category'],
                  'operator'  => 'IN',
                )
    
            ),
        );
    }

    $query = new \WP_Query($args);
    ?>
            <div class="video_playlist_widget">
                <div class="video_wrapper" id="nav-tabContent">
                <?php $i = 0; while ($query->have_posts()) : $query->the_post(); $i++; ?>
                    <div class="main_video <?php echo esc_attr(($i == 1) ? 'show_active' : ''); ?>" id="nav-post-tab-<?php echo esc_attr($this->get_id()); ?>-<?php echo esc_attr($i); ?>">
                        <?php 
                        $prefix = 'daneshyar_';
                        $video_src = get_post_meta(get_the_ID(), $prefix . 'video_upload', true);
                        $poster_src = get_post_meta(get_the_ID(), $prefix . 'video_cover_upload', true);
    
                        $attr =  array(
                            'src'      => $video_src,
                            'poster'   => $poster_src,
                            'preload'  => 'auto',
                        );
                        echo wp_video_shortcode(  $attr );
                        
                         ?>
                    </div>
                    <?php endwhile;
                    wp_reset_query(); ?>

                    <div class="playlist" id="nav-tab" role="tablist">
                    <?php $i = 0; while ($query->have_posts()) : $query->the_post(); $i++; ?>
                        <a class="playlist_item <?php echo esc_attr(($i == 1) ? 'active' : ''); ?>" href="nav-post-tab-<?php echo esc_attr($this->get_id()); ?>-<?php echo esc_attr($i); ?>">
                            <div class="video_thumbnail"><?php the_post_thumbnail('daneshyar-100x80'); ?></div>
                            <div class="meta_data">
                                <h4 class="title"><?php the_title(); ?></h4>
                                <span class="data_publish">
                                    <i class="fa fa-clock-o"></i>
                                    <?php echo get_the_date(); ?>
                                </span>
                            </div>
                        </a>
                        <?php endwhile;
                        wp_reset_query(); ?>
                    </div>
                </div>
            </div>

        <?php
	}
    
}

