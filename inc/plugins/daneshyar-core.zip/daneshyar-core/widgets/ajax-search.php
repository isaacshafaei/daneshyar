<?php
class Elementor_Daneshyar_Search_Widget extends \Elementor\Widget_Base {

	public function get_name() {
		return 'َsearch';
	}

	public function get_title() {
		return esc_html__( 'جستجو ایجکس', 'daneshyar-core' );
	}

	public function get_icon() {
		return 'eicon-search-bold';
	}

	public function get_categories() {
		return [ 'daneshyar-category' ];
	}

	public function get_keywords() {
		return [ 'daneshyar', 'دانشیار' ];
	}

	protected function _register_controls() {

        $this->start_controls_section(
            'daneshyar_search_section',
            [
               'label' => esc_html__( 'Search', 'daneshyar-core' ),
			   'type' => \Elementor\Controls_Manager::SECTION,
            ]
         );

         $this->add_control(
            'daneshyar_search_input',
            [
               'label' => __( 'متن نگه دارنده ی جستجو', 'daneshyar-core' ),
               'type' => \Elementor\Controls_Manager::TEXT,
               'default' => __( 'چی میخوای یاد بگیری..؟'),
   
            ]
         );
   
         $this->add_control(
			'button_bg_color',
			[
				'label' => esc_html__( 'رنگ دکمه سرچ', 'daneshyar-core' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .btn.btn-search' => 'background-color: {{VALUE}}',
				],
			]
		);

         $this->end_controls_section();

   	  }
   
	protected function render(){ 

    $settings = $this->get_settings_for_display(); ?>

    <form class="ajax_search_form" id="head-search" role="search" method="get" action="<?php echo esc_url( home_url( '/' ) ); ?>">
        <div class="search-form-ajax">
            <input autocomplete="off" data-swplive="true" name="s" type="text" class="form-control search-input" placeholder="<?php echo esc_html($settings['daneshyar_search_input']); ?>" required>
            <div class="input-group-append">
                <button class="btn btn-search" type="submit" aria-label="<?php echo __("جستجو", 'daneshyar-core'); ?>">
                    <i class="fa fa-search"></i>
                </button>
            </div>
        </div>
    </form>

        <?php
	}
    
}
