<?php
class Elementor_Daneshyar_Lessons_Widget extends \Elementor\Widget_Base {

	public function get_name() {
		return 'Lessons';
	}

	public function get_title() {
		return esc_html__( 'درس ها', 'daneshyar-core' );
	}

	public function get_icon() {
		return 'eicon-select';
	}

	public function get_categories() {
		return [ 'daneshyar-category' ];
	}

	public function get_keywords() {
		return [ 'daneshyar', 'دانشیار' ];
	}

	protected function _register_controls() {


		$this->start_controls_section(
		   'lesson_section',
		   [
			  'label' => esc_html__( 'تنظیمات فصل', 'daneshyar-core' ),
			  'type' => \Elementor\Controls_Manager::SECTION,
		   ]
		);
   
		  $this->add_control(
			 'image',
			 [
				'label' => __( 'آیکون فصل(اختیاری)', 'daneshyar-core' ),
				'type' => \Elementor\Controls_Manager::MEDIA,
				'default' => [
				   'url' => \Elementor\Utils::get_placeholder_image_src(),
				],
			 ]
		  );
   
		  $this->add_control(
			 'titlelesson',
			 [
				'label' => __( 'عنوان فصل دوره', 'daneshyar-core' ),
				'type' => \Elementor\Controls_Manager::TEXT,
   
			 ]
		  );
   
		  $this->add_control(
			 'subtitlelesson',
			 [
				'label' => __( 'زیرنویس عنوان فصل دوره', 'daneshyar-core' ),
				'type' => \Elementor\Controls_Manager::TEXTAREA,
   
			 ]
		  );
   
   
		  $this->add_control(
			 'arrowsection',
			 [
				'label' => __( 'قابلیت باز و بسته شدن؟', 'daneshyar-core' ),
				'type' => \Elementor\Controls_Manager::SWITCHER,
				'label_on' => esc_html_x("بله", 'daneshyar-core'),
						'label_off' => esc_html_x("خیر", 'daneshyar-core'),
				'default' => 'yes'
   
			 ]
		  );
   
   
		$this->end_controls_section();
   
		 $this->start_controls_section(
			'lessons_section',
			[
			   'label' => esc_html__( 'درس ها', 'daneshyar-core' ),
			   'type' => \Elementor\Controls_Manager::SECTION,
			]
		 );
   
		 $repeater = new \Elementor\Repeater();
   
   
   
		   $repeater->add_control(
			  'private_lesson',
			  [
				 'label' => __( 'دوره خصوصی است؟', 'daneshyar-core' ),
				 'type' => \Elementor\Controls_Manager::SELECT,
				 'default' => 'no',
				 'options' => [
					'yes' => __( 'بله', 'daneshyar-core' ),
					'no' => __( 'خیر', 'daneshyar-core' ),
				 ],
			  ]
		   );
   
   
		   $repeater->add_control(
			  'subtitlelesson',
			  [
				 'label' => __( 'عنوان درس', 'daneshyar-core' ),
				 'type' => \Elementor\Controls_Manager::TEXT,
   
			  ]
		   );
   
		   $repeater->add_control(
			  'subtitlelesson_sub',
			  [
				 'label' => __( 'زیرنویس عنوان', 'learn-soogh' ),
				 'type' => \Elementor\Controls_Manager::TEXT,
   
			  ]
		   );
   
		 $repeater->add_control(
			'icon',
			[
			   'label' => __( 'آیکون درس', 'daneshyar-core' ),
			   'type' => \Elementor\Controls_Manager::ICON,
   
			]
		 );
   
		 $repeater->add_control(
			'label_lesson',
			[
			   'label' => __( 'لیبل درس', 'daneshyar-core' ),
			   'type' => \Elementor\Controls_Manager::SELECT,
			   'default' => '',
			   'options' => [
				  'free' => __( 'رایگان', 'daneshyar-core' ),
				  'video' => __( 'ویدئو', 'daneshyar-core' ),
				  'exam' => __( 'آزمون', 'daneshyar-core' ),
				  'quiz' => __( 'کوئیز', 'daneshyar-core' ),
				  'lecture' => __( 'مقاله', 'daneshyar-core' ),
				  'practice' => __( 'تمرین', 'daneshyar-core' ),
				  'attachments' => __( 'فایل ضمیمه', 'daneshyar-core' ),
				  'sound' => __( 'صوت', 'daneshyar-core' ),
			   ],
			]
		 );
   
   
		 $repeater->add_control(
			'preview_video',
			[
			   'label' => __( 'پیشنمایش ویدئویی', 'daneshyar-core' ),
			   'type' => \Elementor\Controls_Manager::URL
			]
		 );
   
		 $repeater->add_control(
			'download_lesson',
			[
			   'label' => __( 'لینک فایل خصوصی درس', 'daneshyar-core' ),
			   'type' => \Elementor\Controls_Manager::URL
			]
		 );
   
		 $repeater->add_control(
			'lesson_content',
			[
			   'label' => __( 'محتوای دوره', 'daneshyar-core' ),
			   'type' => \Elementor\Controls_Manager::WYSIWYG
			]
		 );
   
   
		 $this->add_control(
			'lessons_list',
			[
			   'label' => __( 'لیست دروس', 'daneshyar-core' ),
			   'type' => \Elementor\Controls_Manager::REPEATER,
			   'fields' => $repeater->get_controls(),
			   'title_field' => '{{{subtitlelesson}}}',
   
			]
		 );
   
		 $this->end_controls_section();   
	  }
   
	protected function render(){ 
		$settings = $this->get_settings_for_display();
		$current_user = wp_get_current_user();

		$bought_course = false;
		if($current_user->user_login and $current_user->ID and wc_customer_bought_product($current_user->user_login,$current_user->ID,get_the_id())){
			$bought_course = true;
		}
		?>
			<div class="elementor-section">
				<div class="course_section <?php if($settings['arrowsection']=='yes'){ echo 'toggleslide'; } ?>">
					<div class="inner_section_lesson">
						<div class="img_lesson"><img src="<?php echo $settings['image']['url'] ?>" alt=""></div>
						<div class="head_text">
							<span><?php echo $settings['titlelesson']; ?></span>
							<p><?php echo $settings['subtitlelesson']; ?></p>
						</div>
					<?php if($settings['arrowsection']=='yes'){ echo '<i class="fal fa-chevron-down"></i>';} ?>
					</div>
					<div class="inner_content_item">
					<?php foreach($settings['lessons_list'] as $lesson_item): ?>
					<div class="panel_group">
						<div class="panel_row">
							<div class="panel_column_right">
								<i class="<?php echo $lesson_item['icon']; ?>"></i>
								<div class="right_panel_text">
									<h4 class="title"><?php echo $lesson_item['subtitlelesson']; 
									$type_label = $lesson_item['label_lesson'];
									?>                         
										<span class="label <?php echo $type_label; ?>"><?php echo change_label_text($type_label); ?></span>
									</h4>
									<p class="subtitle"><?php echo $lesson_item['subtitlelesson_sub']; ?></p>
								</div>
							</div>
							<div class="panel_column_left">
								<?php $preview_video = $lesson_item['preview_video']['url']; 
								if($preview_video):
								?>
									<a href="<?php echo esc_url($preview_video); ?>" class="preview_button">پیش نمایش <i class="fa fa-play-circle"></i></a>
								<?php
								endif; 
								$download_lesson = $lesson_item['download_lesson']['url'];
								if($download_lesson){
									if($bought_course){ ?>
									<a class="download-button" href="<?php echo esc_url($download_lesson); ?>"><i class="fa fa-download"></i></a>
									<?php }
									elseif($lesson_item['private_lesson'] == 'no'){ ?>
									<a class="download-button" href="<?php echo esc_url($download_lesson); ?>"><i class="fa fa-download"></i></a>
									<?php }
									else{ ?>
										<a class="download-button gray"><i class="fa fa-download"></i></a>
									<?php }
								} ?>
								<?php if( $lesson_item["private_lesson"] !== "no" ): ?>
									<div class="private-lesson">

										<?php if($bought_course): ?>
											<?php echo '<i class="fa fa-unlock green-lock"></i>'; ?>
											<?php  else : ?>
												<?php echo '<i class="fa fa-lock"></i>'; ?>
										<?php endif; ?>

										<span>
										<?php if($bought_course): ?>
											<?php echo "در دسترس"; ?>
										<?php else : ?>
											<?php echo "خصوصی"; ?>
										<?php endif; ?>
										</span>

									</div>
								<?php endif; ?>
							</div>
						</div>
					</div>
					<div class="panel_content">
						<?php if( $lesson_item["private_lesson"] == "yes" && $bought_course){ ?>
								<div class="panel_content_inner"><?php echo $lesson_item['lesson_content']; ?></div>
							<?php }elseif($lesson_item["private_lesson"] == "no"){ ?>
								<div class="panel_content_inner"><?php echo $lesson_item['lesson_content']; ?></div>
							<?php }else{
								echo "این دوره خصوصی است و برای دسترسی به محتوای دوره باید آن را خریداری کنید.";
							} ?>
					</div>
					<?php endforeach; ?>
					</div>
				</div>
			</div>
		<?php
	}
}
